import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-image-model',
  templateUrl: './image-model.component.html',
  styleUrls: ['./image-model.component.css']
})
export class ImageModelComponent implements OnInit {

  comments:string;
  @Input() fromParent;
  @Input() imageListArray:[];
  deletedImage: any[];
  // updatedArray: [];
  @Output() updatedArray:[];
  @Input() CommentList:string[];


  constructor(public activeModal: NgbActiveModal) { 
    
  }

  ngOnInit(): void {
    
    console.log("ImageModelComponent -> ngOnInit -> this.imageList", this.imageListArray)
    // console.log("ImageModelComponent -> ngOnInit -> fromParent", this.fromParent)
    this.comments = "";
    this.ShowComment(this.fromParent);
  }
  closeModal(sendData) {
   // if (this.comments !="")
    //{
   this.AddComment(sendData);
  //}
    this.activeModal.close(sendData);
    console.log("ImageModelComponent -> closeModal -> sendData", sendData)
  }

  deleteImage(sendData){
   debugger;
   console.log("ImageModelComponent -> deleteImage -> this.comments)", this.comments)
   this.deletedImage=this.imageListArray.splice(sendData,1);
      this.updatedArray=this.imageListArray
   console.log("ImageModelComponent -> deleteImage -> this.updatedArray", this.updatedArray)
   console.log("ImageModelComponent -> deleteImage -> deletedImage", this.deletedImage)
   this.activeModal.close(sendData);
  }

  AddComment(sendData){
    debugger;
    console.log("ImageModelComponent -> deleteImage -> this.comments)", this.comments)
    let arraylength =this.imageListArray.length;
    for (let index = 0; index < arraylength; index++) {
      if (this.imageListArray[index] == sendData){
        console.log(this.comments + ' ' + index);
        //this.CommentArray.splice(index,0);

        console.log(this.CommentList.length);
        console.log(typeof(this.CommentList));

        //this.CommentList.items[index]=this.comments;
        this.CommentList[index] = this.comments;
      }
      
    }
  }
    ShowComment(sendData){
      
      console.log("ImageModelComponent -> deleteImage -> this.comments)", this.comments)
      console.log(sendData);
      console.log(this.CommentList);
      console.log(this.comments);
      let arraylength =this.imageListArray.length;
      
      for (let index = 0; index < arraylength; index++) {
        if (this.imageListArray[index] == sendData){
         // console.log(this.comments + ' ' + index);
          //this.CommentArray.splice(index,0);
  
          //console.log(this.CommentList.length);
          //console.log(typeof(this.CommentList));
         // this.comments.toString = this.CommentList[index].toString;
  
          //this.CommentList.items[index]=this.comments;
          //this.CommentList[index] = this.comments;

          console.log(this.comments);
          console.log(typeof(this.comments))
        this.comments = this.CommentList[index];
        }
        
      }
   
  }
}
