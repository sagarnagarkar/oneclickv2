import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';

@Component({
  selector: 'app-drag-drop',
  templateUrl: './drag-drop.component.html',
  styleUrls: ['./drag-drop.component.scss']
})
export class DragDropComponent implements OnInit {

  imageList: any[] = [];
  ipAddress: string;
  CommentList : string[] = [];
  constructor(private router:Router) { }

  ngOnInit(): void {
  }
  files: any[] = [];

  /**
   * on file drop handler
   */
  onFileDropped($event) {
    this.prepareFilesList($event);
  }

  /**
   * handle file from browsing
   */
  fileBrowseHandler(files) {
    this.prepareFilesList(files);
  }

  /**
   * Delete file from files list
   * @param index (File index)
   */
  deleteFile(index: number) {
    this.files.splice(index, 1);
  }

  /**
   * Simulate the upload process
   */
  uploadFilesSimulator(index: number) {
    setTimeout(() => {
      if (index === this.files.length) {
        return;
      } else {
        const progressInterval = setInterval(() => {
          if (this.files[index].progress === 100) {
            clearInterval(progressInterval);
            this.uploadFilesSimulator(index + 1);
          } else {
            this.files[index].progress += 5;
          }
        }, 200);
      }
    }, 1000);
  }

  /**
   * Convert Files list to normal array list
   * @param files (Files List)
   */
  prepareFilesList(files: Array<any>) {
    for (const item of files) {
      item.progress = 0;
      this.files.push(item);
    }
    this.uploadFilesSimulator(0);
  }

  /**
   * format bytes
   * @param bytes (File size in bytes)
   * @param decimals (Decimals point)
   */
  formatBytes(bytes, decimals) {
    if (bytes === 0) {
      return '0 Bytes';
    }
    const k = 1024;
    const dm = decimals <= 0 ? 0 : decimals || 2;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
  }
  public fileChangeEvent(fileInput: any) {

    
    if (fileInput.target.files && fileInput.target.files[1]) {
      console.log(fileInput);
      console.log(fileInput.target.files.length);
      this.prepareFilesList(fileInput.target.files);
      for (let index = 0; index < fileInput.target.files.length; index++) {
        // console.log(fileInput.target.files[index].type);
        console.log("ImageViewComponent -> fileChangeEvent -> fileInput.target.files[index].type", fileInput.target.files[index].type)
        if (fileInput.target.files[index].type == "image/jpeg") {
          const reader = new FileReader();

          reader.onload = ((e) => {
            //  this.imageSrc= e.target['result'];
            this.imageList[index] = e.target['result'];
            this.CommentList[index]="";
          });

          reader.readAsDataURL(fileInput.target.files[index]);
          console.log(this.imageList);
        }

      }
      console.log(fileInput);
      

    }
  }
  public ShowImage()
  {
    this.router.navigateByUrl('imageview');
  }
}
